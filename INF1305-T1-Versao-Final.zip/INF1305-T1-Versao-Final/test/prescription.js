var Prescription = artifacts.require("./Prescription.sol");

contract("Prescription", function(accounts) {

	it("Contract initializes with five medications.", function() {
		return Prescription.deployed().then(function(instance) { 
			return instance.medicationsCount();
		}).then(function(count) {
			assert.equal(count, 5);
		});
	});

	it("Contract initializes the medications with the correct values.", function() {
		return Prescription.deployed().then(function(instance) {
			prescriptionInstance = instance;
			return prescriptionInstance.medications(1);
		}).then(function(medication) {
			assert.equal(medication[0], 1, "Contains the correct id.");
			assert.equal(medication[1], "Ibuprofeno - Comprimido 300 mg", "Contains the correct name.");
			assert.equal(medication[2], 0, "Contains the correct quantity.");
			return prescriptionInstance.medications(2);
		}).then(function(medication) {
			assert.equal(medication[0], 2, "Contains the correct id.");
			assert.equal(medication[1], "Ibuprofeno - Suspensão Oral Gotas 50 mg/mL Frasco", "Contains the correct name.");
			assert.equal(medication[2], 0, "Contains the correct quantity.");
			return prescriptionInstance.medications(3);
		}).then(function(medication) {
			assert.equal(medication[0], 3, "Contains the correct id.");
			assert.equal(medication[1], "Paracetamol - Comprimido 500 mg", "Contains the correct name.");
			assert.equal(medication[2], 0, "Contains the correct quantity.");
			return prescriptionInstance.medications(4);
		}).then(function(medication) {
			assert.equal(medication[0], 4, "Contains the correct id.");
			assert.equal(medication[1], "Paracetamol - Solução Oral Gotas 200 mg/mL Frasco", "Contains the correct name.");
			assert.equal(medication[2], 0, "Contains the correct quantity.");
			return prescriptionInstance.medications(5);
		}).then(function(medication) {
			assert.equal(medication[0], 5, "Contains the correct id.");
			assert.equal(medication[1], "Dipirona Sódica + Prometazina + Adifenina - Solução Injetável 750 mg + 25 mg + 25 mg amp. 2 mL", "Contains the correct name.");
			assert.equal(medication[2], 0, "Contains the correct quantity.");
		});
	});


	it("Contract allows a voter to cast a vote.", function() {
	    return Prescription.deployed().then(function(instance) {
	      prescriptionInstance = instance;
	      medicationId = 1;
	      return prescriptionInstance.vote(medicationId, { from: accounts[0] });
	    }).then(function(receipt) {
	      assert.equal(receipt.logs.length, 1, "An event was triggered.");
	      assert.equal(receipt.logs[0].event, "votedEvent", "The event type is correct.");
	      assert.equal(receipt.logs[0].args._medicationId.toNumber(), medicationId, "The medication id is correct.");
	      return prescriptionInstance.voters(accounts[0]);
	    }).then(function(voted) {
	      assert(voted, "The voter was marked as voted.");
	      return prescriptionInstance.medications(medicationId);
	    }).then(function(medication) {
	      var voteCount = medication[2];
	      assert.equal(voteCount, 1, "Increments the medication's vote count.");
	    })
  	});

  	it("Contract throws an exception for invalid medications.", function() {
	    return Prescription.deployed().then(function(instance) {
	      prescriptionInstance = instance;
	      return prescriptionInstance.vote(99, { from: accounts[1] })
	    }).then(assert.fail).catch(function(error) {
	      assert(error.message.indexOf('revert') >= 0, "Error message must contain revert.");
	      return prescriptionInstance.medications(1);
	    }).then(function(medication1) {
	      var voteCount = medication1[2];
	      assert.equal(voteCount, 1, "Medication 1 did not receive any votes.");
	      return prescriptionInstance.medications(2);
	    }).then(function(medication2) {
	      var voteCount = medication2[2];
	      assert.equal(voteCount, 0, "Medication 2 did not receive any votes.");
	      return prescriptionInstance.medications(3);
	    }).then(function(medication3) {
	      var voteCount = medication3[2];
	      assert.equal(voteCount, 0, "Medication 3 did not receive any votes.");
	      return prescriptionInstance.medications(4);
	    }).then(function(medication4) {
	      var voteCount = medication4[2];
	      assert.equal(voteCount, 0, "Medication 4 did not receive any votes.");
	      return prescriptionInstance.medications(5);
	    }).then(function(medication5) {
	      var voteCount = medication5[2];
	      assert.equal(voteCount, 0, "Medication 5 did not receive any votes.");
	    });
  	});

  	// it("Contract throws an exception for double voting.", function() {
	//    return Prescription.deployed().then(function(instance) {
	//      prescriptionInstance = instance;
	//      medicationId = 2;
	//      prescriptionInstance.vote(medicationId, { from: accounts[1] });
	//      return prescriptionInstance.medications(medicationId);
	//    }).then(function(medication) {
	//      var voteCount = medication[2];
	//      assert.equal(voteCount, 1, "Accepts first vote.");
	      // Try to vote again
	//      return prescriptionInstance.vote(medicationId, { from: accounts[1] });
	//    }).then(assert.fail).catch(function(error) {
	//      assert(error.message.indexOf('revert') >= 0, "Error message must contain revert.");
	//      return prescriptionInstance.medications(1);
	//    }).then(function(medication1) {
	//      var voteCount = medication1[2];
	//      assert.equal(voteCount, 1, "Medication 1 did not receive any votes.");
	//      return electionInstance.medications(2);
	//    }).then(function(medication2) {
	//      var voteCount = medication2[2];
	//      assert.equal(voteCount, 1, "Medication 2 did not receive any votes.");
	//    });
  	//});

});